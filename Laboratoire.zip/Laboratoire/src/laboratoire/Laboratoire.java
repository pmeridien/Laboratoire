/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package laboratoire;

import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.plaf.nimbus.NimbusLookAndFeel;

/**
 *
 * @author Kevin Nelson
 * @author Pierre Meridien Laury
 */
public class Laboratoire {

    /**
     * Ce Laboratoire consiste en la création d'un répertoire téléphonique Il
     * inclu la posssibilité d'ajour un nom suivi d'un numéro de téléphone Il
     * permet également d'en supprimer un de la liste
     * @param args the command line arguments
     * @throws javax.swing.UnsupportedLookAndFeelException
     */
    public static void main(String[] args) throws UnsupportedLookAndFeelException {

        new Repertoire(); //Création du répertoire
    }

}
