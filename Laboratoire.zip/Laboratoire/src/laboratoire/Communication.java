/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package laboratoire;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


/**
 * @author Kevin Nelson
 * @author Pierre Meridien Laury
 */
public class Communication implements ActionListener {



    private Ajouter ajout;
    private Repertoire repo;
    
/**
 *  Constructeur contenant le Repertoire
 * @param rep 
 */
   public Communication(Repertoire rep) {
      this.repo = rep;
    }

   /**
    * Constructeur contenant la classe Ajouter
    * @param ajout 
    */
    public Communication(Ajouter ajout) {
        this.ajout = ajout;
    }

/**
 *  Action Performed qui permet d'ajouter ou de supprimer un champ
 * @param e 
 */
    @Override
    public void actionPerformed(ActionEvent e) {

        if (ajout != null && e.getSource() == ajout.getBoutonOk()) {
              ajout.getFenetre().getListModel1().addElement(ajout.getNom().getText() + " "
                      + " "+ajout.getPhoneNumber().getText()); // Ajout de l'entrée au panel/Frame initial (Repertoire)
        }else{ // Si la liste contient des entrées alors on supprime le champ sélectionné
            int i = repo.getMonRepertoire().getSelectedIndex(); // Récupération de l'index
            repo.getListModel1().removeElementAt(i); // Retrait de la valeur à l'index récupérée
        }
      


        
    }

}
