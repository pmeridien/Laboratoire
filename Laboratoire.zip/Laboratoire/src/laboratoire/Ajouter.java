/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package laboratoire;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author Kevin Nelson
 * @author Pierre Meridien Laury
 */
public class Ajouter implements ActionListener {

    private Repertoire fenetre; //  objet faisant reférence à la classe répertoire
    private JFrame frame;  // Nouveau frame
    private JPanel newPanel; // Nouveau panel
    private JLabel label;
    private JTextField nom;
    private JLabel l1;  // Label qui suit le nom
    private JLabel l2;  // Label qui suit le numero de telephone
    private JButton boutonOk;
    private JTextField phoneNumber;

    /**
     * Constructeur prenant en paramètre l'objet faisant référence à la classe
     * Répertoire
     *
     * @param fenetre
     */
    public Ajouter(Repertoire fenetre) {
        this.fenetre = fenetre;
    }
    
/**
 * Constructeur vide
 */
    public Ajouter() {
    }
/**
 * Récupération du nom entré par l'utilisateur
 * @return 
 */
    public JTextField getNom() {
        return nom;
    }
/**
 * Modification de la valeur entrée par l'utilisateur
 * @param nom 
 */
    public void setNom(JTextField nom) {
        this.nom = nom;
    }

    /**
     *  Récupération du numéro de téléphone entré par l'utilisateur
     * @return phoned
     */
    public JTextField getPhoneNumber() {
        return phoneNumber;
    }
/**
 * Modification de la valeur entrée par l'utilisateur
 * @param phoneNumber 
 */
    public void setPhoneNumber(JTextField phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    
/**
 *  Méthode permettant d'afficher la nouvelle fenêtre lorsque l'utilisateur presse la touche Ajouter
 * @param e 
 */
    @Override
    public void actionPerformed(ActionEvent e) {
        frame = new JFrame();  // Instanciation du frame
        newPanel = new JPanel();  // Instanciation du panel
        frame.setTitle("Telephone");  // Titre de la nouvelle fenetre
        newPanel.setLayout(new GridLayout(5, 1));  // Disposition des bouttons

        label = new JLabel();

        l1 = new JLabel("Nom: ");
        nom = new JTextField();

        phoneNumber = new JTextField();
        l2 = new JLabel("Telephone: ");

        boutonOk = new JButton("OK");

        newPanel.add(l1);  // Ajout du Label "Nom""  au panel
        newPanel.add(nom);  // Field sur le panel
        newPanel.add(l2);  // Ajout du Label "phoneNumber""  au panel
        newPanel.add(phoneNumber); // Field Number sur le panel
        newPanel.add(boutonOk);  // Boutton OK sur le panel
        frame.add(newPanel);  // Ajout du panel sur le frame

        boutonOk.addActionListener(new Communication(this));  // Appel de la classe communication pour afficher
        frame.setSize(270, 200); // Taille de la fenetre
        frame.setLocationRelativeTo(null);  //centrer l'affichage au milieu
        frame.setVisible(true);  //Affichage de la fenetre
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);  // Femeture de la fenetre sans sortir du programme

    }
/**
 * Récupération de valeur du boutton OK
 * @return 
 */
    public JButton getBoutonOk() {
        return boutonOk;
    }
/**
 * Recuperation de la fenetre generer dans la classe Repertoire
 * @return 
 */
    public Repertoire getFenetre() {
        return fenetre;
    }

}
