/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package laboratoire;

import java.awt.FlowLayout;
import java.awt.HeadlessException;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.plaf.nimbus.NimbusLookAndFeel;

/**
 *
 * @author Kevin Nelson
 * @author Pierre Meridien Laury
 */
public class Repertoire extends JFrame {

    @SuppressWarnings("FieldMayBeFinal")
    private JPanel panel;  // Nouveau panel
    private JButton ajouter;  // Bouton ajouter
    private JButton supprimer;  // Bouton supprimer
    private JMenuBar menu;  // Menu contenant les boutons ajouter et supprimer
    private static JList monRepertoire;   // Liste qui va contenir nos infos
    @SuppressWarnings("FieldMayBeFinal")
    private DefaultListModel listModel1;  // Création d'un model par default qui va contenir notre liste

    /**
     * Récupération referant à la classe Ajouter
     *
     * @return
     */
    public JButton getAjouter() {
        return ajouter;
    }

    /**
     * Modification classe Ajouter
     *
     * @param ajouter
     */
    public void setAjouter(JButton ajouter) {
        this.ajouter = ajouter;
    }

    @SuppressWarnings("OverridableMethodCallInConstructor")
    public Repertoire() throws HeadlessException, UnsupportedLookAndFeelException {
        super("Répertoire téléphonique");  // Titre du la fenetre principal
        UIManager.setLookAndFeel(new NimbusLookAndFeel()); //Amélioration du look de l'affichage
        monRepertoire = new JList<>();  // Utilisation d'une JList pour afficher les infos
        listModel1 = new DefaultListModel();  // Création du Model par défaut
//        String st="Test Ajout";
//        listModel1.addElement(st);

        monRepertoire.setModel(listModel1);  // Modification du model
        panel = new JPanel(); // Création du panel

        panel.setLayout(new FlowLayout());  // Utilisation du FlowLayout pour afficher les infos
        setJMenuBar(createMenuBar(panel));  // Ajout et creation du menu
        panel.add(monRepertoire);  // Ajout du repertoire sur le panel
        add(panel); // Ajout du panel sur le Frame

        ajouter.addActionListener(new Ajouter(this)); // Action Listener sur le bouton Ajouter

        supprimer.addActionListener(new Communication(this)); // Action Listener sur le bouton Supprimer

        this.setSize(350, 400);
        this.setLocationRelativeTo(null); // Affichage centrer
        this.setVisible(true);  //Affichage de la fenetre
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  //Fermeture du programme

    }

    private JMenuBar createMenuBar(JPanel panel) {
        menu = new JMenuBar(); // instanciation du menuBar
        menu.setLayout(new FlowLayout(FlowLayout.LEFT)); // Séparation des boutons ajouter et supprimer
        ajouter = new JButton("Ajouter");
        supprimer = new JButton("Supprimer");

        menu.add(ajouter);  // Ajout du bouton ajouter sur le panel
        menu.add(supprimer); // Ajout du bouton supprimer sur le panel
        panel.add(menu);  // ajout du menu sur le panel
        return menu;  // Retour du menu
    }

    /**
     * Recuperation de la JList
     *
     * @return JList
     */
    public JList getMonRepertoire() {
        return monRepertoire;
    }

    /**
     * Récupération du Model
     *
     * @return Model
     */
    public DefaultListModel getListModel1() {
        return listModel1;
    }

}
